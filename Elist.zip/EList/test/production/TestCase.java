package production;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCase 
{

	int[] mass = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	int[] mass2 = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10};
	int[] mass3 = {0, 0, 0, 0, 0, 0};
	int[] mass4 = {1, 1, 1, 1, 1, 1};
	int[] mass5 = {1, 0, 4, 4, 5, 11, 5, 100, 0, 3};
	int[] mass6 = null;
	int[] mass7 = {5};
	
	
	
	
//	-------------------------------------------- minElementMass
	@Test
	public void minElementMass1() 
	{
		EList ins = new EList();
		ins.iinit(mass);
		int act = ins.minElementMass();
		assertEquals(1, act);
	}
	
	@Test
	public void minElementMass2() 
	{
		EList ins = new EList();
		ins.iinit(mass2);
		int act = ins.minElementMass();
		assertEquals(10, act);
	}
	
	@Test
	public void minElementMass3() 
	{
		EList ins = new EList();
		ins.iinit(mass3);
		int act = ins.minElementMass();
		assertEquals(0, act);
	}
	
	@Test
	public void minElementMass4() 
	{
		EList ins = new EList();
		ins.iinit(mass4);
		int act = ins.minElementMass();
		assertEquals(1, act);
	}
	
	@Test
	public void minElementMass5() 
	{
		EList ins = new EList();
		ins.iinit(mass5);
		int act = ins.minElementMass();
		assertEquals(0, act);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void minElementMass6() 
	{
		EList ins = new EList();
		ins.iinit(mass6);
		int act = ins.minElementMass();
	}
	
	@Test
	public void minElementMass7() 
	{
		EList ins = new EList();
		ins.iinit(mass7);
		int act = ins.minElementMass();
		assertEquals(5, act);
	}
	
	
//	-------------------------------------------- maxElementMass
	
	@Test
	public void maxElementMass() 
	{
		EList ins = new EList();
		ins.iinit(mass);
		int act = ins.maxElementMass();
		assertEquals(10, act);
	}
	
	@Test
	public void maxElementMass2() 
	{
		EList ins = new EList();
		ins.iinit(mass2);
		int act = ins.maxElementMass();
		assertEquals(100, act);
	}
	
	@Test
	public void maxElementMass3() 
	{
		EList ins = new EList();
		ins.iinit(mass3);
		int act = ins.maxElementMass();
		assertEquals(0, act);
	}
	
	@Test
	public void maxElementMass4() 
	{
		EList ins = new EList();
		ins.iinit(mass4);
		int act = ins.maxElementMass();
		assertEquals(1, act);
	}
	
	@Test
	public void maxElementMass5() 
	{
		EList ins = new EList();
		ins.iinit(mass5);
		int act = ins.maxElementMass();
		assertEquals(100, act);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void maxElementMass6() 
	{
		EList ins = new EList();
		ins.iinit(mass6);
		int act = ins.maxElementMass();
	}
	
	@Test
	public void maxElementMass7() 
	{
		EList ins = new EList();
		ins.iinit(mass7);
		int act = ins.maxElementMass();
		assertEquals(5, act);
	}

//	-------------------------------------------- indexMinElement
	
	@Test
	public void indexMinElement() 
	{
		EList ins = new EList();
		ins.massiv(mass);
		int act = ins.indexMinElement();
		assertEquals(0, act);
	}

	@Test
	public void indexMinElement2() 
	{
		EList ins = new EList();
		ins.massiv(mass2);
		int act = ins.indexMinElement();
		assertEquals(9, act);
	}

	@Test
	public void indexMinElement3() 
	{
		EList ins = new EList();
		ins.massiv(mass3);
		int act = ins.indexMinElement();
		assertEquals(0, act);
	}

	@Test
	public void indexMinElement4() 
	{
		EList ins = new EList();
		ins.massiv(mass4);
		int act = ins.indexMinElement();
		assertEquals(0, act);
	}

	@Test
	public void indexMinElement5() 
	{
		EList ins = new EList();
		ins.massiv(mass5);
		int act = ins.indexMinElement();
		assertEquals(1, act);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void indexMinElement6() 
	{
		EList ins = new EList();
		ins.massiv(mass6);
		int act = ins.indexMinElement();
	}
	
	@Test
	public void indexMinElement7() 
	{
		EList ins = new EList();
		ins.massiv(mass7);
		int act = ins.indexMinElement();
		assertEquals(0, act);
	}



//-------------------------------------------- indexMaxElement

@Test
public void indexMaxElement() 
{
	EList ins = new EList();
	ins.massiv(mass);
	int act = ins.indexMaxElement();
	assertEquals(9, act);
}

@Test
public void indexMaxElement2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	int act = ins.indexMaxElement();
	assertEquals(0, act);
}

@Test
public void indexMaxElement3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	int act = ins.indexMaxElement();
	assertEquals(0, act);
}

@Test
public void indexMaxElement4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	int act = ins.indexMaxElement();
	assertEquals(0, act);
}

@Test
public void indexMaxElement5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	int act = ins.indexMaxElement();
	assertEquals(7, act);
}

@Test (expected = IllegalArgumentException.class)
public void indexMaxElement6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	int act = ins.indexMaxElement();
}

@Test
public void indexMaxElement7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	int act = ins.indexMaxElement();
	assertEquals(0, act);
}

//-------------------------------------------- sumElementNeChetIndex

@Test
public void sumElementNeChetIndex() 
{
	EList ins = new EList();
	ins.massiv(mass);
	int act = ins.sumElementNeChetIndex();
	assertEquals(30, act);
}

@Test
public void sumElementNeChetIndex2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	int act = ins.sumElementNeChetIndex();
	assertEquals(250, act);
}

@Test
public void sumElementNeChetIndex3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	int act = ins.sumElementNeChetIndex();
	assertEquals(0, act);
}

@Test
public void sumElementNeChetIndex4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	int act = ins.sumElementNeChetIndex();
	assertEquals(3, act);
}

@Test
public void sumElementNeChetIndex5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	int act = ins.sumElementNeChetIndex();
	assertEquals(118, act);
}

@Test (expected = IllegalArgumentException.class)
public void sumElementNeChetIndex6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	int act = ins.sumElementNeChetIndex();
}

@Test
public void sumElementNeChetIndex7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	int act = ins.sumElementNeChetIndex();
	assertEquals(0, act);
}

//-------------------------------------------- reverseMass

@Test
public void reverseMass() 
{
	EList ins = new EList();
	ins.massiv(mass);
	ins.reverseMass();
	int[] exp = {10,9,8,7,6,5,4,3,2,1};
	assertArrayEquals(exp, mass);
}

@Test
public void reverseMass2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	ins.reverseMass();
	int[] exp = {10,20,30,40,50,60,70,80,90,100};
	assertArrayEquals(exp, mass2);
}

@Test
public void reverseMass3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	ins.reverseMass();
	int[] exp = {0,0,0,0,0,0};
	assertArrayEquals(exp, mass3);
}

@Test
public void reverseMass4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	ins.reverseMass();
	int[] exp = {1,1,1,1,1,1};
	assertArrayEquals(exp, mass4);
}

@Test
public void reverseMass5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	ins.reverseMass();
	int[] exp = {3,0,100,5,11,5,4,4,0,1};
	assertArrayEquals(exp, mass5);
}

@Test (expected = IllegalArgumentException.class)
public void reverseMass6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	ins.reverseMass();
}

@Test
public void reverseMass7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	ins.reverseMass();
	int[] exp = {5};
	assertArrayEquals(exp, mass7);
}


//-------------------------------------------- kolvoNeChetElement

@Test
public void kolvoNeChetElement() 
{
	EList ins = new EList();
	ins.massiv(mass);
	int act = ins.kolvoNeChetElement();
	assertEquals(5, act);
}

@Test
public void kolvoNeChetElement2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	int act = ins.kolvoNeChetElement();
	assertEquals(0, act);
}

@Test
public void kolvoNeChetElement3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	int act = ins.kolvoNeChetElement();
	assertEquals(0, act);
}

@Test
public void kolvoNeChetElement4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	int act = ins.kolvoNeChetElement();
	assertEquals(6, act);
}

@Test
public void kolvoNeChetElement5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	int act = ins.kolvoNeChetElement();
	assertEquals(5, act);
}

@Test (expected = IllegalArgumentException.class)
public void kolvoNeChetElement6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	int act = ins.kolvoNeChetElement();
}

@Test
public void kolvoNeChetElement7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	int act = ins.kolvoNeChetElement();
	assertEquals(1, act);
}


//-------------------------------------------- polovinaMass


@Test
public void polovinaMass() 
{
	EList ins = new EList();
	ins.massiv(mass);
	ins.polovinaMass();
	int[] exp = {6,7,8,9,10,1,2,3,4,5};
	assertArrayEquals(exp, mass);
}

@Test
public void polovinaMass2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	ins.polovinaMass();
	int[] exp = {50,40,30,20,10,100,90,80,70,60};
	assertArrayEquals(exp, mass2);
}

@Test
public void polovinaMass3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	ins.polovinaMass();
	int[] exp = {0,0,0,0,0,0};
	assertArrayEquals(exp, mass3);
}

@Test
public void polovinaMass4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	ins.polovinaMass();
	int[] exp = {1,1,1,1,1,1};
	assertArrayEquals(exp, mass4);
}

@Test
public void polovinaMass5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	ins.polovinaMass();
	int[] exp = {11,5,100,0,3,1,0,4,4,5};
	assertArrayEquals(exp, mass5);
}

@Test (expected = IllegalArgumentException.class)
public void polovinaMass6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	ins.polovinaMass();
}

@Test (expected = IllegalArgumentException.class)
public void polovinaMass7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	ins.polovinaMass();
}

//-------------------------------------------- sortPuzir

@Test
public void sortPuzir() 
{
	EList ins = new EList();
	ins.massiv(mass);
	ins.sortPuzir();
	int[] exp = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	assertArrayEquals(exp, mass);
}

@Test
public void sortPuzir2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	ins.sortPuzir();
	int[] exp = {10,20,30,40,50,60,70,80,90,100};
	assertArrayEquals(exp, mass2);
}

@Test
public void sortPuzir3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	ins.sortPuzir();
	int[] exp = {0,0,0,0,0,0};
	assertArrayEquals(exp, mass3);
}

@Test
public void sortPuzir4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	ins.sortPuzir();
	int[] exp = {1,1,1,1,1,1};
	assertArrayEquals(exp, mass4);
}

@Test
public void sortPuzir5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	ins.sortPuzir();
	int[] exp = {0,0,1,3,4,4,5,5,11,100};
	assertArrayEquals(exp, mass5);
}

@Test (expected = IllegalArgumentException.class)
public void sortPuzir6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	ins.sortPuzir();
}

@Test
public void sortPuzir7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	ins.sortPuzir();
	int[] exp = {5};
	assertArrayEquals(exp, mass7);
}


//-------------------------------------------- sortSelect


@Test
public void sortSelect() 
{
	EList ins = new EList();
	ins.massiv(mass);
	ins.sortSelect();
	int[] exp = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	assertArrayEquals(exp, mass);
}

@Test
public void sortSelect2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	ins.sortSelect();
	int[] exp = {10,20,30,40,50,60,70,80,90,100};
	assertArrayEquals(exp, mass2);
}

@Test
public void sortSelect3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	ins.sortSelect();
	int[] exp = {0,0,0,0,0,0};
	assertArrayEquals(exp, mass3);
}

@Test
public void sortSelect4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	ins.sortSelect();
	int[] exp = {1,1,1,1,1,1};
	assertArrayEquals(exp, mass4);
}

@Test
public void sortSelect5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	ins.sortSelect();
	int[] exp = {0,0,1,3,4,4,5,5,11,100};
	assertArrayEquals(exp, mass5);
}

@Test (expected = IllegalArgumentException.class)
public void sortSelect6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	ins.sortSelect();
}

@Test
public void sortSelect7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	ins.sortSelect();
	int[] exp = {5};
	assertArrayEquals(exp, mass7);
}

//-------------------------------------------- sortInsert


@Test
public void sortInsert() 
{
	EList ins = new EList();
	ins.massiv(mass);
	ins.sortInsert();
	int[] exp = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	assertArrayEquals(exp, mass);
}

@Test
public void sortInsert2() 
{
	EList ins = new EList();
	ins.massiv(mass2);
	ins.sortInsert();
	int[] exp = {10,20,30,40,50,60,70,80,90,100};
	assertArrayEquals(exp, mass2);
}

@Test
public void sortInsert3() 
{
	EList ins = new EList();
	ins.massiv(mass3);
	ins.sortInsert();
	int[] exp = {0,0,0,0,0,0};
	assertArrayEquals(exp, mass3);
}

@Test
public void sortInsert4() 
{
	EList ins = new EList();
	ins.massiv(mass4);
	ins.sortInsert();
	int[] exp = {1,1,1,1,1,1};
	assertArrayEquals(exp, mass4);
}

@Test
public void sortInsert5() 
{
	EList ins = new EList();
	ins.massiv(mass5);
	ins.sortInsert();
	int[] exp = {0,0,1,3,4,4,5,5,11,100};
	assertArrayEquals(exp, mass5);
}

@Test (expected = IllegalArgumentException.class)
public void sortInsert6() 
{
	EList ins = new EList();
	ins.massiv(mass6);
	ins.sortInsert();
}

@Test
public void sortInsert7() 
{
	EList ins = new EList();
	ins.massiv(mass7);
	ins.sortInsert();
	int[] exp = {5};
	assertArrayEquals(exp, mass7);
}


}
