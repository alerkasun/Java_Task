package production;

public class AList0 implements EList
{

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void init(int[] ar) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addStart(int a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addEnd(int a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addPos(int a, int pos) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delStart() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delEnd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delPos(int a, int pos) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int minValue() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int maxValue() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int minIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int maxIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void reverse() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeparts() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sortBubble() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sortSelect() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sortInsert() {
		// TODO Auto-generated method stub
		
	}

}